// for canvas
let canvasWidth = 1000;
let canvasHeight = 700;
// for bird 
let bird = {
  initX: canvasHeight * 0.3,
  initY: canvasHeight / 2,
  initSpeed: -10,
  diameter: 30,
  jumpSpeed: -10
}

var gravity = 0.5;

function preload() {
  font = loadFont('assets/fonts/Inconsolata.ttf');
  bg = loadImage('assets/images/bg.jpg');
}

function setup() {
  createCanvas(canvasWidth, canvasHeight);
  flappy = new Bird(bird.initX, bird.initY, bird.diameter, bird.jumpSpeed, bird.initSpeed);
  env = new Course(canvasWidth, canvasHeight);
  textFont(font);
  textSize(40);
  textAlign(CENTER, CENTER);
  noStroke();
  loop();
}

function draw() {
  background(bg);
  flappy.run(gravity);
  env.run();
  fill(255);
  text(Math.floor(flappy.score), 0.9 * canvasWidth, 0.9 * canvasHeight)
  flappy.dead = hasCollided();
  if(flappy.dead) {
    gameOver();
  }
}

function mouseClicked() {
  flappy.jump();
  beep('G4');
}

function hasCollided() {
  if(flappy.y > env.canvas.h || flappy.y < 0) {
    return true;
  }
  for(var i = 0; i < env.doors.length; i++) {
    var door = env.doors[i];
    if(flappy.x + flappy.d / 2 <= door.x) {
      break;
    }
    if(flappy.x + flappy.d / 2 > door.x && flappy.x - flappy.d / 2 < door.x + door.w) {
      if(flappy.y - flappy.d / 2 < door.y || flappy.y + flappy.d / 2 > door.y + door.h) {
        return true;
      }
      else {
        return false;
      }
    }
  }
  return false;
}

function gameOver() {
  beep('Fb4');
  text("Game Over!\nPress any key to restart.", canvasWidth / 2, canvasHeight / 2);
  noLoop();
}

function keyPressed() {
  setup();
}

function beep(note) {
  userStartAudio();
  let monoSynth = new p5.MonoSynth();
  let velocity = random();
  let time = 0;
  let dur = 1 / 100;
  monoSynth.play(note, velocity, time, dur);
}